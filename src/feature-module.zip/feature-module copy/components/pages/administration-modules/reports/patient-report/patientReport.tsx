import { useState } from "react";
import { PatientReportData } from "../../../../../../core/json/patientReportData";
import TagInput from "../../../../../../core/common/Taginput";
import PredefinedDatePicker from "../../../../../../core/common/datePicker";
import {
  Designation,
  Location,
  Patient,
  Practioner,
} from "../../../../../../core/common/selectOption";
import CommonSelect from "../../../../../../core/common/common-select/commonSelect";
import Datatable from "../../../../../../core/common/dataTable";
import { Link } from "react-router";
import PageHeader from "../../../../../../core/common/page-header/PageHeader";
import ImageWithBasePath from "../../../../../../core/imageWithBasePath";

const PatientReport = () => {
  const data = PatientReportData;
  const columns = [
    {
      title: "Patient",
      dataIndex: "Patient",
      sorter: (a: any, b: any) => a.Patient.length - b.Patient.length,
    },
    {
      title: "Age/Gender",
      dataIndex: "AgeGender",
      sorter: (a: any, b: any) => a.AgeGender.length - b.AgeGender.length,
    },
    {
      title: "Contact Info",
      dataIndex: "ContactInfo",
      render: (text: any, render: any) => (
        <>
          <p className="text-dark mb-0">{text}</p>
          <span>{render.Email}</span>
        </>
      ),
      sorter: (a: any, b: any) => a.ContactInfo.length - b.ContactInfo.length,
    },
    {
      title: "Practioner",
      dataIndex: "Practioner",
      render: (text: any) => <p className="text-dark fw-medium">{text}</p>,
      sorter: (a: any, b: any) => a.Practioner.length - b.Practioner.length,
    },
    {
      title: "Location",
      dataIndex: "Location",
      sorter: (a: any, b: any) => a.Location.length - b.Location.length,
    },
    {
      title: "Last Visit",
      dataIndex: "LastVisit",
      sorter: (a: any, b: any) => a.LastVisit.length - b.LastVisit.length,
    },
    {
      title: "Status",
      dataIndex: "Status",
      render: (text: string) => (
        <span
          className={`badge ${
            text === "Available"
              ? "badge-soft-success border border-success"
              : "badge-soft-danger border border-danger"
          }  px-2 py-1 fs-13 fw-medium`}
        >
          {text}
        </span>
      ),
      sorter: (a: any, b: any) => a.Status.length - b.Status.length,
    },
  ];

  const [tags2, setTags2] = useState<string[]>(["Received", "Pending"]);
  const handleTagsChange2 = (newTags: string[]) => {
    setTags2(newTags);
  };
  return (
    <>
      {/* ========================
			Start Page Content
		========================= */}
      <div className="page-wrapper">
        {/* Start Content */}
        <div className="content">
          {/* Start Page Header */}
          <PageHeader
            title="Patients Report"
            className="mb-3 pb-3 border-bottom"
            actions={
              <div className="dropdown me-1">
                <Link
                  to="#"
                  className="btn btn-md fs-14 fw-normal border bg-white rounded text-dark d-inline-flex align-items-center"
                  data-bs-toggle="dropdown"
                >
                  Export
                  <i className="ti ti-chevron-down ms-2" />
                </Link>
                <ul className="dropdown-menu p-2">
                  <li>
                    <Link className="dropdown-item" to="#">
                      Download as PDF
                    </Link>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="#">
                      Download as Excel
                    </Link>
                  </li>
                </ul>
              </div>
            }
          />
          {/* End Page Header */}
          {/* row start*/}
          <div className="row">
            {/* col start */}
            <div className="col-xl-3 col-md-6 d-flex">
              <div className="card shadow-sm flex-fill w-100 z-0">
                <ImageWithBasePath
                  src="./assets/img/bg/widget-bg-09.svg"
                  alt="img"
                  className="position-absolute end-0 bottom-0 z-n1"
                />
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <div>
                      <p className="mb-1 text-truncate">Total Patients</p>
                      <h6 className="mb-0 fw-bold">1,240</h6>
                    </div>
                    <span className="avatar avatar-lg bg-primary rounded-circle flex-shrink-0">
                      <i className="ti ti-users fs-24" />
                    </span>
                  </div>
                  <span className="mb-0 fs-13 d-block border-top rounded-2 pt-2">
                    <span className="text-success">
                      <i className="ti ti-arrow-up-right me-1" />
                      5.62%
                    </span>
                    from last month
                  </span>
                </div>
              </div>
            </div>
            {/* col end */}
            {/* col start */}
            <div className="col-xl-3 col-md-6 d-flex">
              <div className="card shadow-sm flex-fill w-100 z-0">
                <ImageWithBasePath
                  src="./assets/img/bg/widget-bg-10.svg"
                  alt="img"
                  className="position-absolute end-0 bottom-0 z-n1"
                />
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <div>
                      <p className="mb-1 text-truncate">New Patients</p>
                      <h6 className="mb-0 fw-bold">210</h6>
                    </div>
                    <span className="avatar avatar-lg bg-success rounded-circle flex-shrink-0">
                      <i className="ti ti-users-plus fs-24" />
                    </span>
                  </div>
                  <span className="mb-0 fs-13 d-block border-top rounded-2 pt-2">
                    <span className="text-success">
                      <i className="ti ti-arrow-up-right me-1" />
                      11.4%
                    </span>
                    from last month
                  </span>
                </div>
              </div>
            </div>
            {/* col end */}
            {/* col start */}
            <div className="col-xl-3 col-md-6 d-flex">
              <div className="card shadow-sm flex-fill w-100 z-0">
                <ImageWithBasePath
                  src="./assets/img/bg/widget-bg-11.svg"
                  alt="img"
                  className="position-absolute end-0 bottom-0 z-n1"
                />
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <div>
                      <p className="mb-1 text-truncate">Appointment Booked</p>
                      <h6 className="mb-0 fw-bold">500</h6>
                    </div>
                    <span className="avatar avatar-lg bg-warning rounded-circle flex-shrink-0">
                      <i className="ti ti-bookmarks fs-24" />
                    </span>
                  </div>
                  <span className="mb-0 fs-13 d-block border-top rounded-2 pt-2">
                    <span className="text-success">
                      <i className="ti ti-arrow-up-right me-1" />
                      8.52%
                    </span>
                    from last month
                  </span>
                </div>
              </div>
            </div>
            {/* col end */}
            {/* col start */}
            <div className="col-xl-3 col-md-6 d-flex">
              <div className="card shadow-sm flex-fill w-100 z-0">
                <ImageWithBasePath
                  src="./assets/img/bg/widget-bg-12.svg"
                  alt="img"
                  className="position-absolute end-0 bottom-0 z-n1"
                />
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <div>
                      <p className="mb-1 text-truncate">Returning Patients</p>
                      <h6 className="mb-0 fw-bold">380</h6>
                    </div>
                    <span className="avatar avatar-lg bg-danger rounded-circle flex-shrink-0">
                      <i className="ti ti-users-minus fs-24" />
                    </span>
                  </div>
                  <span className="mb-0 fs-13 d-block border-top rounded-2 pt-2">
                    <span className="text-danger">
                      <i className="ti ti-arrow-down-right me-1" />
                      7.45%
                    </span>
                    from last month
                  </span>
                </div>
              </div>
            </div>
            {/* col end */}
          </div>
          {/* row end */}
          <div className="card">
            <div className="card-body">
              {/* start row */}
              <div className="row row-gap-2">
                <div className="col-lg-4">
                  <div className="mb-0">
                    <label className="form-label">Date</label>
                    <div className="report-rangepicker position-relative">
                      <PredefinedDatePicker />
                      <span className="input-icon-addon fs-14 text-dark">
                        <i className="ti ti-calendar" />
                      </span>
                    </div>
                  </div>
                </div>
                {/* end col */}
                <div className="col-lg-4">
                  <div className="mb-0">
                    <label className="form-label">Patient</label>
                    <CommonSelect
                      options={Patient}
                      className="select"
                      defaultValue={Patient[0]}
                    />
                  </div>
                </div>
                {/* end col */}
                <div className="col-lg-4">
                  <div className="mb-0">
                    <label className="form-label">Location</label>
                    <CommonSelect
                      options={Location}
                      className="select"
                      defaultValue={Location[0]}
                    />
                  </div>
                </div>
                {/* end col */}
                <div className="col-lg-4">
                  <div className="mb-0">
                    <label className="form-label">Practioner</label>
                    <CommonSelect
                      options={Practioner}
                      className="select"
                      defaultValue={Practioner[0]}
                    />
                  </div>
                </div>
                {/* end col */}
                <div className="col-lg-4">
                  <div className="mb-0">
                    <label className="form-label">Designation</label>
                    <CommonSelect
                      options={Designation}
                      className="select"
                      defaultValue={Designation[0]}
                    />
                  </div>
                </div>
                {/* end col */}
                <div className="col-lg-4">
                  <div className="mb-0">
                    <label className="form-label">Status</label>
                    <TagInput
                      initialTags={tags2}
                      onTagsChange={handleTagsChange2}
                    />
                  </div>
                </div>
                {/* end col */}
                <div className="col-md-12">
                  <div className="d-flex align-items-center justify-content-end">
                    <Link to="#" className="btn btn-dark">
                      <i className="ti ti-player-play me-1" />
                      Run Report
                    </Link>
                  </div>
                </div>
                {/* end col */}
              </div>
              {/* end row */}
            </div>
            {/* end card body */}
          </div>
          {/* end card */}
          <div className="table-responsive">
            <Datatable
              columns={columns}
              dataSource={data}
              Selection={false}
              searchText={""}
            />
          </div>
        </div>
        {/* End Content */}
        {/* Footer Start */}
        <div className="footer text-center bg-white p-2 border-top">
          <p className="text-dark mb-0">
            2025 ©
            <Link to="#" className="link-primary">
              Symplify
            </Link>
            , All Rights Reserved
          </p>
        </div>
        {/* Footer End */}
      </div>
      {/* ========================
			End Page Content
		========================= */}
    </>
  );
};

export default PatientReport;
